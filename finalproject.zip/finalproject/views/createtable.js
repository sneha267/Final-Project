var mysql = require('mysql');
var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "root123",
  database: "mydbnewlvl3"
});
con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");
  /*Create a table named "customers":*/
  var sql = "CREATE TABLE customer (p_id int, pname VARCHAR(255), quantity int)";
  con.query(sql, function (err, result) {
    if (err) throw err;
    console.log("Table created");
  });
});