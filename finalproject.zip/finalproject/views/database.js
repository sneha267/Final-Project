var mysql = require('mysql');
var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "root123",
database:"mydbnewlvl30"
});
con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");
  /*Create a database named "mydb":
  */
 //con.query("CREATE TABLE sample_data(id int primary key not null, first_name varchar(255), last_name varchar(255), age varchar(255), gender varchar(255))", function (err, result) {
    con.query("select * from sample_data", function (err, result) {    
if (err) throw err;
    console.log("Database created");
  });
});
